from .mobilenet import mobilenet_v2

get_model_from_name = {
    "mobilenet": mobilenet_v2,
}